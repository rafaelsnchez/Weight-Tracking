package com.zybooks.projecttwo;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

public class databaseInfo extends AppCompatActivity {
    private TableLayout tbleLayout;
    private EditText enter_weight, date, goal_weight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_database_info);

        tbleLayout = (TableLayout) findViewById(R.id.table_layout);
        enter_weight = (EditText) findViewById(R.id.weight_input);
        date = (EditText) findViewById(R.id.date_input);
        goal_weight = (EditText) findViewById(R.id.goal_weight_input);
    }
    public void AddToTable(View view) {

        TableRow tbleRow = new TableRow(this);
        tbleRow.setLayoutParams(new TableRow.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        tbleRow.setBackgroundColor(Color.parseColor("#C8C5C5"));
        tbleRow.setPadding(5, 5, 5, 5);
        TextView tx1 = new TextView(this);
        TextView tx2 = new TextView(this);
        TextView tx3 = new TextView(this);
        String e_weight = enter_weight.getText().toString(),
                e_date = date.getText().toString(),
                eg_weight = goal_weight.getText().toString();
        if (e_weight.isEmpty() || e_date.isEmpty() || eg_weight.isEmpty()) {
            Toast.makeText(this, "Please Fill In All Areas", Toast.LENGTH_SHORT).show();
            return;
        }

        tx1.setText(e_weight);
        tx2.setText(e_date);
        tx3.setText((eg_weight));
        Button button = new Button(this);
        button.setText("Delete");
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteRow(v);
            }
        });

        tbleRow.addView(tx1);
        tbleRow.addView(tx2);
        tbleRow.addView(tx3);
        tbleRow.addView(button);
        tbleLayout.addView(tbleRow);

        enter_weight.setText("");
        date.setText("");
        goal_weight.setText("");

    }

    public void deleteRow(View v) {
        View row = (View) v.getParent();
        ViewGroup container = ((ViewGroup) row.getParent());
        container.removeView(row);
        container.invalidate();
    }
}
