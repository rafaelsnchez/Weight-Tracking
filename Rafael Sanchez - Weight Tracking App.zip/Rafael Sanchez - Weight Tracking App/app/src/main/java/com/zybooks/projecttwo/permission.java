package com.zybooks.projecttwo;

import android.Manifest;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class permission extends AppCompatActivity {

    private int RECEIVE_SMS_PERMISSION_CODE =1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.permission_granted);
        Button grant_permission =(Button) findViewById(R.id.permission);
        grant_permission.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                seekPermission(v);
                //Toast.makeText(PromptActivity.this,"Grant Permission Button Clicked",Toast.LENGTH_SHORT).show();

            }
        });
    }

    public void seekPermission(View view) {
        if (ContextCompat.checkSelfPermission(
                permission.this, Manifest.permission.RECEIVE_SMS) ==
                PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(permission.this, "Permission has already been granted", Toast.LENGTH_SHORT).show();
        } else{

            if (ActivityCompat.shouldShowRequestPermissionRationale(permission.this, Manifest.permission.RECEIVE_SMS)) {

                new AlertDialog.Builder(this)
                        .setTitle("Permission is required")
                        .setMessage("This permission required to receive automated system notifications")
                        .setPositiveButton("ALLOW", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                ActivityCompat.requestPermissions(permission.this, new String[]{Manifest.permission.RECEIVE_SMS}, RECEIVE_SMS_PERMISSION_CODE);
                            }
                        })
                        .setNegativeButton("DENY", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        })
                        .create().show();
            } else {
                Toast.makeText(permission.this,"Congratulations!",Toast.LENGTH_SHORT).show();
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECEIVE_SMS}, RECEIVE_SMS_PERMISSION_CODE);

            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if(requestCode == RECEIVE_SMS_PERMISSION_CODE){
            if(grantResults.length >0 && grantResults[0]== PackageManager.PERMISSION_GRANTED){
                Toast.makeText(this, "Permission Granted", Toast.LENGTH_SHORT).show();
            }else{
                Toast.makeText(this, "Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
