package com.zybooks.projecttwo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button button, button_resetPassword, button_Signup;
    EditText user_name, password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        user_name=(EditText)findViewById(R.id.Username);
        password=(EditText)findViewById(R.id.Password);
        button =(Button) findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(validateInput(v)) {
                    Intent intent = new Intent(MainActivity.this, permission.class);
                    startActivity(intent);
                }
            }
        });
        button =(Button) findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(validateInput(v)) {
                    Intent intent = new Intent(MainActivity.this, databaseInfo.class);
                    startActivity(intent);
                }
            }
        });
        button_resetPassword =(Button)findViewById(R.id.button_resetPassword);
        button_resetPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Coming soon!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public boolean validateInput(View v){

        if(user_name.getText().toString().isEmpty() ||password.getText().toString().isEmpty()){
            Toast.makeText(this, "Please Fill in All Areas", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }
}